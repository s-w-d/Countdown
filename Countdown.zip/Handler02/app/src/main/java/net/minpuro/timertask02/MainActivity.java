package net.minpuro.timertask02;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    TextView textView;
    ImageView imageView;

    Timer timer;
    TimerTask timerTask;

    int count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textView);
        imageView = findViewById(R.id.imageView);

        count = 3;

        timer = new Timer();
        timerTask = new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        count -= 1;
                        textView.setText(String.valueOf(count));
                        if (count == 0) {
                            timer.cancel();
                            imageView.setImageResource(R.drawable.cat_134_140);
                        }
                    }
                });
            }
        };
        timer.schedule(timerTask, 1000, 1000);

    }


}

